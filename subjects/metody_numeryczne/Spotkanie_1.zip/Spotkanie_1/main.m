function main
   c = f1(2)
   c = f2(2)
end

function a = f1(x)
    a = 0
    for i = 1:3
        %a = 678;
        %a = a/2*x;
        a = a + x^2;
    end
    a
end

function a = f2(x)
    a = x+2;
end
