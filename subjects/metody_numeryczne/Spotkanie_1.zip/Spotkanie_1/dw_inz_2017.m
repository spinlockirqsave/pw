function dw_inz_2017
    close all;
    up = -1: 0.25 : 1;
    ip = [0.01, -0.02 0.02 -0.01 0 0.08 0.22 0.6 0.98];
    
    plot(up, ip, 's');
    xlabel('up');
    ylabel('ip');
    
    h = 0.01;
    T = 0: h :2*pi;
    figure;
    Ut = sin(T);
    It = spline(up, ip, Ut);
    Pt = Ut .* It;
    plot(T, Ut, T, It, T, Pt);
    
    %n = length(T);
    %s = 0;
    %for j = 1:n-1
    %    s = s + Ut(j) * It(j) * h;
    %end
    %s
    
    S = Ut(1:end-1)*It(1:end-1)'*h
end