function pierwszy3
    close all;
    Y = [];
    Y(1) = 1.0;
    T = [];
    t = 0;
    i = 1;
    Tend = 1;
    h = 0.01;
    
    T = 0 : h : Tend;
    
    while (t < Tend)
        Y(i+1) = Y(i) + h * f(T(i), Y(i));
        Y(i+1) = Y(i) + h * (-15*Y(i));
        i = i  + 1;
        t = t + h;
    end
    
    plot(T, Y, 's-')
    title('Rozwiazanie!!!')
    legend('-15t')
end


function dy = f(t,y)
    dy = -15 * y;
end