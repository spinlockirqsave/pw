#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	char *katalog;
	DIR *dir;
	struct dirent *pozycja;
	
	switch(argc)
	{
         case 1: katalog = ".";
                 break;
         case 2: katalog = argv[1];
                 break;
         default : printf("Poprawna skladnia:\t%s katalog\n", argv[0]);
                   exit(1);
        }
	
	if ((dir = opendir(katalog)) == NULL)
	{
		perror("Blad opendir");
		return 1;
	}
	
	errno = 0;
	while ((pozycja = readdir(dir)) != NULL)
		printf("%s\n", pozycja->d_name);
	
	if (errno)
	{
		perror("Blad readdir");
		return 1;
	}
	if (closedir(dir) == -1)
	{
		perror("Blad closedir");
		return 1;
	}
	
	return 0;
}

